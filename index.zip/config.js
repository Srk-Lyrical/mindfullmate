// Google Gemini API Configuration
const GEMINI_API_KEY = 'AIzaSyBIWAsWBT4DaN6DKd5R69Q8VSPX7v-I0T8';

// Export for use in other files
export { GEMINI_API_KEY };
